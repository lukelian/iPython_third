#-*- coding:utf-8 -*-

class Solution():
    def solve(self, x):
    	pass
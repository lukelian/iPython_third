# !/bin/bash
# python <python测试文件> <python代码文件>

cd $1/problem
python $1/.mooctest/testcase/testProblem.py $1/problem/problem.py
